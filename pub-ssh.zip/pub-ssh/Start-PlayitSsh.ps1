<#
.SYNOPSIS
    Makes the SSH host on this computer reachable from the internet through playit.gg.
    No administrator rights are needed.

.DESCRIPTION
    playit.gg relays TCP traffic for you: your machine makes an outbound connection to playit,
    and playit forwards incoming connections back to your local SSH port. No router changes and
    no public IP, so this is the simplest way to reach sshd from outside.

    This script:

      1. Checks that sshd is installed and actually listening (it can start it if asked).
      2. Downloads the portable playit agent into %LOCALAPPDATA%\\playit if it is missing,
         verifying that it is a real Windows executable.
      3. Prints exactly what to do in the playit.gg dashboard: point your tunnel at
         127.0.0.1:<SshPort> with protocol TCP.
      4. Optionally starts the agent in the background (no window) and, when you know your
         assigned address, prints the ready-to-paste ssh command.

    The agent is portable: it stores its agent secret under your own profile and, with
    -StartAgent, runs hidden in the background with its output written to a log file. Nothing is
    installed as a service and no elevation is involved. Stop it with
    "Get-Process playit | Stop-Process" or .\Uninstall-Tools.ps1 -Playit.

.PARAMETER SshPort
    Local SSH port that playit should forward to. Default 2222.

.PARAMETER StartAgent
    Start the playit agent after preparing everything, hidden in the background with no window
    (its output goes to a log file). Without this, only the setup is done and the commands are
    printed.

.PARAMETER StartSshd
    Start the SSH host first when it is not listening yet.

.PARAMETER TunnelAddress
    Your playit.gg address for this tunnel, for example "mybox.at.playit.gg:34567". When given,
    the script prints the final ssh command for it.

.PARAMETER AgentPath
    Use an existing playit.exe instead of downloading one.

.EXAMPLE
    .\Start-PlayitSsh.ps1

    Prepares the agent, prints the dashboard step and the ssh command.

.EXAMPLE
    .\Start-PlayitSsh.ps1 -StartSshd -StartAgent -TunnelAddress mybox.at.playit.gg:34567

.EXAMPLE
    .\Start-PlayitSsh.ps1 -SshPort 6969

.NOTES
    If script execution is still refused, allow it once for your own account (no admin):

        Get-ChildItem -Path .\*.ps1 | Unblock-File
        Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
#>
[CmdletBinding()]
param(
    [ValidateRange(1024, 65535)]
    [int]$SshPort = 2222,

    [switch]$StartAgent,

    [switch]$StartSshd,

    [string]$TunnelAddress,

    [string]$AgentPath
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Write-Step {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Write-Ok {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "[ ok ] $Message" -ForegroundColor Green
}

function Write-Warn {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "[warn] $Message" -ForegroundColor Yellow
}

function Write-Info {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "     $Message" -ForegroundColor Gray
}

function Test-LocalPortListening {
    param(
        [string]$ComputerName = '127.0.0.1',
        [Parameter(Mandatory)][int]$Port,
        [int]$TimeoutMs = 700
    )

    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $connect = $client.ConnectAsync($ComputerName, $Port)
        if (-not $connect.Wait($TimeoutMs)) { return $false }
        return $client.Connected
    } catch {
        return $false
    } finally {
        $client.Dispose()
    }
}

function Get-PlayitArchTag {
    # Release assets are named playit-windows-<tag>-signed.exe; 32-bit shells on 64-bit Windows
    # report X86, so prefer PROCESSOR_ARCHITEW6432.
    $candidates = @()
    if (-not [string]::IsNullOrWhiteSpace($env:PROCESSOR_ARCHITEW6432)) { $candidates += $env:PROCESSOR_ARCHITEW6432 }
    if (-not [string]::IsNullOrWhiteSpace($env:PROCESSOR_ARCHITECTURE)) { $candidates += $env:PROCESSOR_ARCHITECTURE }
    foreach ($candidate in $candidates) {
        switch ($candidate.ToUpperInvariant()) {
            'AMD64' { return 'x86_64' }
            'ARM64' { return 'x86_64' }   # no native ARM64 asset; x64 runs under emulation
            'X86'   { return 'x86' }
        }
    }
    throw "Unsupported CPU architecture '$env:PROCESSOR_ARCHITECTURE'."
}

function Get-PlayitDownloadUrl {
    param([Parameter(Mandatory)][string]$ArchTag)
    return "https://github.com/playit-cloud/playit-agent/releases/latest/download/playit-windows-$ArchTag-signed.exe"
}

function Get-PlayitAgentPath {
    # The executable name is repeated here on purpose: depending on a script-scope variable makes
    # this function return a bare directory when called from a different scope, which then fails
    # much later with a confusing "cannot find playit" message.
    param([string]$ExplicitPath)

    if (-not [string]::IsNullOrWhiteSpace($ExplicitPath)) {
        if (-not (Test-Path -LiteralPath $ExplicitPath -PathType Leaf)) {
            throw "No playit agent found at '$ExplicitPath'."
        }
        return (Resolve-Path -LiteralPath $ExplicitPath).Path
    }
    if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
        throw 'LOCALAPPDATA is not set, so the agent folder cannot be resolved.'
    }
    $path = Join-Path (Join-Path $env:LOCALAPPDATA 'playit') 'playit.exe'
    if ([string]::IsNullOrWhiteSpace((Split-Path -Leaf $path))) {
        throw 'Could not build a path for the playit agent.'
    }
    return $path
}

function Install-PlayitAgent {
    param([Parameter(Mandatory)][string]$TargetPath)

    if (Test-Path -LiteralPath $TargetPath -PathType Container) {
        throw "The playit target '$TargetPath' is a folder, not the agent executable."
    }

    if (Test-Path -LiteralPath $TargetPath -PathType Leaf) {
        Write-Ok "playit agent already present: $TargetPath"
        return $TargetPath
    }

    $arch = Get-PlayitArchTag
    $url = Get-PlayitDownloadUrl -ArchTag $arch
    Write-Step "Downloading the playit.gg agent ($arch)"
    Write-Info $url

    $targetDir = Split-Path -Parent $TargetPath
    New-Item -ItemType Directory -Path $targetDir -Force | Out-Null

    $tempFile = Join-Path ([IO.Path]::GetTempPath()) ('playit-' + [guid]::NewGuid().ToString('N') + '.exe')
    try {
        try {
            Invoke-WebRequest -Uri $url -OutFile $tempFile -UseBasicParsing
        } catch {
            Write-Warn "Invoke-WebRequest failed: $($_.Exception.Message)"
            if ($null -eq (Get-Command -Name 'curl.exe' -ErrorAction SilentlyContinue)) { throw }
            & curl.exe -fsSL $url -o $tempFile
            if ($LASTEXITCODE -ne 0) { throw "Could not download $url" }
        }

        if (-not (Test-Path -LiteralPath $tempFile -PathType Leaf)) { throw 'The download produced no file.' }
        $length = (Get-Item -LiteralPath $tempFile).Length
        if ($length -lt 1MB) { throw "Downloaded file is only $length bytes; probably an error page." }

        $stream = [IO.File]::OpenRead($tempFile)
        try {
            $magic = New-Object byte[] 2
            $bytesRead = $stream.Read($magic, 0, 2)
        } finally {
            $stream.Dispose()
        }
        if ($bytesRead -ne 2 -or $magic[0] -ne 0x4D -or $magic[1] -ne 0x5A) {
            throw 'Downloaded file is not a Windows executable (no MZ header).'
        }

        Move-Item -LiteralPath $tempFile -Destination $TargetPath -Force
    } finally {
        if (Test-Path -LiteralPath $tempFile) {
            Remove-Item -LiteralPath $tempFile -Force -ErrorAction SilentlyContinue
        }
    }

    Write-Ok "Installed playit agent: $TargetPath"

    try {
        $signature = Get-AuthenticodeSignature -FilePath $TargetPath
        if ($signature.Status -eq 'Valid') {
            Write-Ok "Signature valid ($($signature.SignerCertificate.Subject))"
        } else {
            Write-Warn "Authenticode status: $($signature.Status)"
        }
    } catch {
        Write-Warn "Could not check the signature: $($_.Exception.Message)"
    }

    return $TargetPath
}

function Get-SshCommand {
    # The connection port comes from the playit address, not from sshd's local port.
    param([string]$Address)

    if ([string]::IsNullOrWhiteSpace($Address)) { return $null }

    $hostPart = $Address
    $portPart = '25565'
    if ($Address -match '^(?<host>[^:]+):(?<port>\d+)$') {
        $hostPart = $Matches['host']
        $portPart = $Matches['port']
    } elseif ($Address -match ':') {
        throw "Could not read '$Address'. Use the form host.at.playit.gg:port."
    }

    return "ssh -p $portPart $env:USERNAME@$hostPart"
}

function Invoke-Main {
    param(
        [int]$Port,
        [switch]$Agent,
        [switch]$SshdStart,
        [string]$Address,
        [string]$Path
    )

    $isWindowsHost = $true
    if ($null -ne $IsWindows) { $isWindowsHost = [bool]$IsWindows }
    if (-not $isWindowsHost) {
        throw 'This script targets Windows. On other platforms install these with your package manager.'
    }
    if ([string]::IsNullOrWhiteSpace($env:USERPROFILE)) {
        throw 'USERPROFILE is not set, so the per-user setup cannot be resolved.'
    }

    Write-Host ''
    Write-Host ' SSH over playit.gg (no admin required)' -ForegroundColor White
    Write-Host ' ---------------------------------------' -ForegroundColor DarkGray

    # ---- 1. is the SSH server there and listening? ----
    $listening = Test-LocalPortListening -Port $Port
    if ($listening) {
        Write-Ok "sshd is listening on port $Port"
    } else {
        $sshdConfig = Join-Path (Join-Path $env:USERPROFILE '.ssh-host') 'sshd_config'
        if (-not (Test-Path -LiteralPath $sshdConfig)) {
            Write-Warn 'sshd does not look installed yet (no sshd_config in %USERPROFILE%\.ssh-host).'
            Write-Info 'Run: .\Install-Sshd.ps1 -GenerateClientKey -Start'
        } else {
            Write-Warn "sshd is configured but nothing is listening on port $Port."
            Write-Info "Start it with: .\Install-Sshd.ps1 -Port $Port -Start"
        }

        if ($SshdStart) {
            $installer = Join-Path (if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }) 'Install-Sshd.ps1'
            if (-not (Test-Path -LiteralPath $installer)) {
                throw "Install-Sshd.ps1 was not found next to this script."
            }
            Write-Step 'Starting the SSH host'
            & $installer -Port $Port -Start
            if ($LASTEXITCODE -ne 0) {
                throw "Install-Sshd.ps1 exited with code $LASTEXITCODE."
            }
            $listening = Test-LocalPortListening -Port $Port
            if (-not $listening) {
                Write-Warn "Still nothing listening on port $Port; the dashboard step below will not work yet."
            }
        }
    }

    # ---- 2. agent binary ----
    $agentTarget = Get-PlayitAgentPath -ExplicitPath $Path
    $agentTarget = Install-PlayitAgent -TargetPath $agentTarget
    if ([string]::IsNullOrWhiteSpace($agentTarget) -or -not (Test-Path -LiteralPath $agentTarget -PathType Leaf)) {
        throw "The playit agent could not be resolved (got '$agentTarget'). Run .\Install-Tools.ps1 from the pub-ssh folder."
    }

    # ---- 3. the one browser step ----
    Write-Host ''
    Write-Host ' Dashboard step (playit.gg account needed):' -ForegroundColor White
    Write-Host "     Point your tunnel at  127.0.0.1:$Port  with protocol TCP" -ForegroundColor Gray
    Write-Host '     If you already have a TCP tunnel, just confirm its local port matches.' -ForegroundColor Gray
    Write-Host ''
    if (-not $Agent) {
        Write-Host ' Or start the agent yourself (opens a window):' -ForegroundColor White
        Write-Host "     & `"$agentTarget`"" -ForegroundColor Gray
        Write-Host ''
        Write-Host ' First run only: the agent prints a claim URL; open it and finish the claim.' -ForegroundColor Gray
    }

    $sshCommand = Get-SshCommand -Address $Address
    if ($sshCommand) {
        Write-Host ''
        Write-Host ' Connect from anywhere with:' -ForegroundColor White
        Write-Host "     $sshCommand" -ForegroundColor Gray
    } else {
        Write-Host ''
        Write-Host ' Then connect with the address playit shows for the tunnel:' -ForegroundColor White
        Write-Host "     ssh -p <playit-port> $env:USERNAME@<your-tunnel>.at.playit.gg" -ForegroundColor Gray
        Write-Info 'Pass -TunnelAddress host.at.playit.gg:port to have this printed for you.'
    }

    Write-Host ''
    Write-Info 'Login is key based: put your public key in %USERPROFILE%\.ssh\authorized_keys'
    Write-Info '   or run: .\Install-Sshd.ps1 -AddAuthorizedKey "ssh-ed25519 AAAA... you@laptop"'
    Write-Info 'Remove the agent later with: .\Uninstall-Tools.ps1 -Playit'
    Write-Host ''

    # ---- 4. start it now, hidden in the background ----
    if ($Agent) {
        $existing = @(Get-Process -Name 'playit' -ErrorAction SilentlyContinue)
        if ($existing.Count -gt 0) {
            Write-Ok "The agent is already running (PID $(($existing | ForEach-Object { $_.Id }) -join ', '))."
            return
        }

        Write-Step 'Starting the playit agent in the background (no window)'
        $logDir = Split-Path -Parent $agentTarget
        $outLog = Join-Path $logDir 'playit.log'
        $errLog = Join-Path $logDir 'playit.err.log'
        Remove-Item -LiteralPath $outLog, $errLog -Force -ErrorAction SilentlyContinue

        # -WindowStyle Hidden keeps it off the desktop; the process is detached, so it keeps
        # running after this script and the terminal close. Sending its output to a log (rather
        # than a console) is what lets a first-run claim link be surfaced without a window. If a
        # host refuses the redirection, fall back to a plain hidden launch.
        $captured = $true
        try {
            $agentProc = Start-Process -FilePath $agentTarget -WindowStyle Hidden -PassThru `
                -RedirectStandardOutput $outLog -RedirectStandardError $errLog
        } catch {
            $captured = $false
            $agentProc = Start-Process -FilePath $agentTarget -WindowStyle Hidden -PassThru
        }

        Write-Ok "Agent running in the background (PID $($agentProc.Id))."
        Write-Info 'Stop it with:  Get-Process playit | Stop-Process     (or .\Uninstall-Tools.ps1 -Playit)'
        if ($captured) { Write-Info "Log: $outLog" }

        # A machine that has not been claimed yet needs a one-time browser authorization: the
        # agent prints a claim link to its output. Surface it so no window is needed. An
        # already-claimed agent prints no claim link and just connects.
        $claimUrl = $null
        if ($captured) {
            for ($i = 0; $i -lt 16 -and -not $claimUrl; $i++) {
                Start-Sleep -Milliseconds 500
                $lines = @(Get-Content -LiteralPath $outLog, $errLog -ErrorAction SilentlyContinue)
                foreach ($line in $lines) {
                    if ($line -match 'claim') {
                        $m = [regex]::Match($line, 'https?://\S+')
                        if ($m.Success) { $claimUrl = $m.Value.TrimEnd('.', ',', ')', ']'); break }
                    }
                }
                if ($claimUrl -or $agentProc.HasExited) { break }
                if ($lines -match 'tunnel|connected|authenticated') { break }
            }
        }

        if ($claimUrl) {
            Write-Host ''
            Write-Host ' First run on this machine - authorize the agent once:' -ForegroundColor White
            Write-Host "     $claimUrl" -ForegroundColor Cyan
            Write-Host ' Open that link, finish the claim on playit.gg, and it stays connected from then on.' -ForegroundColor Gray
        } elseif (-not $captured) {
            Write-Host ''
            Write-Info 'If this machine is not claimed yet, run the agent once in a visible window to claim it:'
            Write-Info "     & `"$agentTarget`""
        } else {
            Write-Info 'No claim link seen, so this machine is already authorized and the agent reconnected.'
        }
    }
}

try {
    Invoke-Main -Port $SshPort -Agent:$StartAgent -SshdStart:$StartSshd -Address $TunnelAddress -Path $AgentPath
} catch {
    Write-Host ''
    Write-Host "[error] $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
