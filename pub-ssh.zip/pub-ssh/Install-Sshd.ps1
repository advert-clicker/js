<#
.SYNOPSIS
    Runs a user-mode Win32-OpenSSH sshd as the current user, with no administrator rights
    and no Windows service.

.DESCRIPTION
    Prefers the OpenSSH that ships with Windows 10/11, so usually nothing is downloaded.
    Copies sshd.exe and its helpers into %LOCALAPPDATA%\openssh-host (nothing depends on
    Scoop folders or shims), generates host keys and sshd_config in %USERPROFILE%\.ssh-host,
    and can start the server.

    Key facts this design respects:
      * Windows only allows a non-elevated sshd to listen above port 1023, so the default is 2222.
      * A user-mode sshd cannot read logon events, so password login is unavailable; key-based
        login is used and keys are generated for you.
      * sshd must not run elevated: as admin it would authenticate you as SYSTEM, so this
        script refuses to run from an elevated shell.

.PARAMETER Port
    SSH listening port, default 2222 (must be 1024 or higher).

.PARAMETER AddAuthorizedKey
    Public key (contents or a .pub path) authorized for login.

.PARAMETER NoTrustedKeysFile
    Do not authorize the keys listed in trusted-keys.txt.

.PARAMETER GenerateClientKey
    Create and authorize a client key pair in %USERPROFILE%\.ssh-host\client.

.PARAMETER Start
    Start sshd at the end and verify it is listening.

.PARAMETER UseScoop
    scoop install openssh, copy the daemon out, then remove Scoop's copy.

.PARAMETER BootstrapScoop
    Install Scoop itself when -UseScoop needs it.

.PARAMETER OpenSshSource
    Folder that already contains sshd.exe.

.PARAMETER InstallDir
    Daemon copy folder. Default %LOCALAPPDATA%\openssh-host.

.PARAMETER ConfigDir
    Config and host-key folder. Default %USERPROFILE%\.ssh-host.

.EXAMPLE
    .\Install-Sshd.ps1 -GenerateClientKey -Start

.EXAMPLE
    .\Install-Sshd.ps1 -Port 2222 -AddAuthorizedKey (Get-Content .\id_ed25519.pub) -Start

.NOTES
    If script execution is still refused, allow it once for your own account (no admin):

        Get-ChildItem -Path .\*.ps1 | Unblock-File
        Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
#>
[CmdletBinding()]
param(
    [ValidateRange(1024, 65535)]
    [int]$Port = 2222,

    [string]$AddAuthorizedKey,

    [switch]$NoTrustedKeysFile,

    [switch]$GenerateClientKey,

    [switch]$UseScoop,

    [switch]$BootstrapScoop,

    [switch]$Start,

    [string]$OpenSshSource,

    [string]$InstallDir,

    [string]$ConfigDir
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$script:HostExeName = 'sshd.exe'
$script:SshHostDir = $InstallDir
$script:SshConfigDir = $ConfigDir
$script:SshdFiles = @(
    'sshd.exe', 'sshd-session.exe', 'sshd-auth.exe', 'ssh-shellhost.exe',
    'sftp-server.exe', 'ssh-pkcs11-helper.exe', 'ssh-sk-helper.exe', 'ssh-keygen.exe',
    'libcrypto.dll', 'moduli', 'sshd_config_default', 'LICENSE.txt', 'NOTICE.txt'
)
$script:KeyNames = @{ Rsa = 'ssh_host_rsa_key'; Ed25519 = 'ssh_host_ed25519_key' }

# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------
function Write-Step {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Write-Ok {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "[ ok ] $Message" -ForegroundColor Green
}

function Write-Warn {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "[warn] $Message" -ForegroundColor Yellow
}

function Write-Info {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "     $Message" -ForegroundColor Gray
}

function Initialize-KeyPair {
    # ssh-keygen prompts for a passphrase when -N is missing, and an empty-string argument is
    # not marshalled reliably to a native command by Windows PowerShell 5.1 (that failure looks
    # like "Too many arguments" from ssh-keygen). On Windows the whole command line is therefore
    # built as one string and handed to cmd.exe, where -N "" keeps its empty value. Elsewhere
    # the arguments are passed as an explicit string list, which both PS 5.1 and PS 7 handle.
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$KeyGenPath,
        [Parameter(Mandatory)][string]$KeyPath,
        [Parameter(Mandatory)][string]$KeyType
    )

    if (-not (Test-Path -LiteralPath $KeyGenPath -PathType Leaf)) {
        throw "ssh-keygen.exe was not found at '$KeyGenPath'."
    }

    $output = $null
    $onWindows = $true
    if ($null -ne $IsWindows) { $onWindows = [bool]$IsWindows }

    if ($onWindows -and $null -ne (Get-Command -Name 'cmd.exe' -ErrorAction SilentlyContinue)) {
        $commandLine = '"' + $KeyGenPath + '" -q -t ' + $KeyType + ' -N "" -f "' + $KeyPath + '"'
        $output = cmd.exe /c $commandLine 2>&1
    } else {
        # The empty passphrase must still be an argument, so -N is followed by an empty string.
        $arguments = [System.Collections.Generic.List[string]]::new()
        foreach ($token in @('-q', '-t', $KeyType, '-N', '', '-f', $KeyPath)) { $arguments.Add($token) }
        $output = & $KeyGenPath $arguments.ToArray() 2>&1
    }

    if ($LASTEXITCODE -ne 0) {
        $detail = (($output | Out-String).Trim())
        throw "ssh-keygen failed to create $KeyPath (exit code $LASTEXITCODE). $detail"
    }
}

function Test-IsElevated {
    try {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch {
        return $false
    }
}

function Test-SshdHostPrereq {
    if (-not [string]::IsNullOrWhiteSpace($env:LOCALAPPDATA) -and [string]::IsNullOrWhiteSpace($script:SshHostDir)) {
        $script:SshHostDir = Join-Path $env:LOCALAPPDATA 'openssh-host'
    }
    if (-not [string]::IsNullOrWhiteSpace($env:USERPROFILE) -and [string]::IsNullOrWhiteSpace($script:SshConfigDir)) {
        $script:SshConfigDir = Join-Path $env:USERPROFILE '.ssh-host'
    }

    $isWindowsHost = $true
    if ($null -ne $IsWindows) { $isWindowsHost = [bool]$IsWindows }
    if (-not $isWindowsHost) {
        throw 'This script targets Windows.'
    }
    if (Test-IsElevated) {
        throw 'Run this from a normal, non-elevated PowerShell window. An elevated sshd would authenticate you as SYSTEM.'
    }
    if ([string]::IsNullOrWhiteSpace($env:USERPROFILE)) {
        throw 'USERPROFILE is not set, so a per-user configuration cannot be created.'
    }
}

function Get-SystemOpenSshDir {
    # Windows 10/11 ship OpenSSH here, so often nothing needs downloading.
    $candidates = @()
    if ($env:SystemRoot) { $candidates += (Join-Path $env:SystemRoot 'System32\OpenSSH') }
    if ($env:ProgramFiles) { $candidates += (Join-Path $env:ProgramFiles 'OpenSSH-Win64') }
    if (${env:ProgramFiles(x86)}) { $candidates += (Join-Path ${env:ProgramFiles(x86)} 'OpenSSH-Win64') }
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath (Join-Path $candidate 'sshd.exe') -PathType Leaf) { return $candidate }
    }
    return $null
}

function Get-ScoopOpenSshDir {
    if ([string]::IsNullOrWhiteSpace($env:USERPROFILE)) { return $null }
    $app = Join-Path $env:USERPROFILE 'scoop\apps\openssh\current'
    if (Test-Path -LiteralPath (Join-Path $app 'sshd.exe') -PathType Leaf) { return $app }
    return $null
}

function Get-CpuTag {
    # 32-bit shell on 64-bit Windows reports X86, so prefer PROCESSOR_ARCHITEW6432.
    $candidates = @()
    if (-not [string]::IsNullOrWhiteSpace($env:PROCESSOR_ARCHITEW6432)) { $candidates += $env:PROCESSOR_ARCHITEW6432 }
    if (-not [string]::IsNullOrWhiteSpace($env:PROCESSOR_ARCHITECTURE)) { $candidates += $env:PROCESSOR_ARCHITECTURE }
    foreach ($candidate in $candidates) {
        switch ($candidate.ToUpperInvariant()) {
            'AMD64' { return 'Win64' }
            'ARM64' { return 'ARM64' }
            'X86'   { return 'Win32' }
        }
    }
    throw "Unsupported CPU architecture '$env:PROCESSOR_ARCHITECTURE'."
}

function Copy-OpenSshRuntime {
    param(
        [Parameter(Mandatory)][string]$Source,
        [Parameter(Mandatory)][string]$Target
    )

    if (-not (Test-Path -LiteralPath (Join-Path $Source 'sshd.exe') -PathType Leaf)) {
        throw "No sshd.exe found in '$Source'."
    }

    New-Item -ItemType Directory -Path $Target -Force | Out-Null
    foreach ($name in $script:SshdFiles) {
        $from = Join-Path $Source $name
        if (Test-Path -LiteralPath $from -PathType Leaf) {
            Copy-Item -LiteralPath $from -Destination (Join-Path $Target $name) -Force
        }
    }
    # Any extra runtime DLLs must travel with the daemon too.
    foreach ($file in @(Get-ChildItem -LiteralPath $Source -Filter '*.dll' -File -ErrorAction SilentlyContinue)) {
        Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $Target $file.Name) -Force
    }
}

function Save-OpenSshSource {
    # Downloads the official Win32-OpenSSH build and copies it into the target folder.
    param([Parameter(Mandatory)][string]$TargetDir)

    $tag = Get-CpuTag
    $url = "https://github.com/PowerShell/Win32-OpenSSH/releases/latest/download/OpenSSH-$tag.zip"
    $zip = Join-Path ([IO.Path]::GetTempPath()) ('openssh-' + [guid]::NewGuid().ToString('N') + '.zip')
    $extract = Join-Path ([IO.Path]::GetTempPath()) ('openssh-' + [guid]::NewGuid().ToString('N'))

    Write-Step "Downloading Win32-OpenSSH ($tag) from the official Microsoft repository"
    Write-Info $url
    try {
        Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
        Expand-Archive -LiteralPath $zip -DestinationPath $extract -Force
        $source = $extract
        $inner = @(Get-ChildItem -LiteralPath $extract -Directory)
        if ($inner.Count -eq 1 -and (Test-Path -LiteralPath (Join-Path $inner[0].FullName 'sshd.exe'))) {
            $source = $inner[0].FullName
        }
        Copy-OpenSshRuntime -Source $source -Target $TargetDir
        Write-Ok "Extracted OpenSSH into $TargetDir"
    } finally {
        foreach ($path in @($zip, $extract)) {
            if ($path -and (Test-Path -LiteralPath $path)) {
                Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction SilentlyContinue
            }
        }
    }
}

function Install-OpenSshViaScoop {
    param([switch]$BootstrapScoop)

    $scoop = Get-Command -Name 'scoop' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $scoop) {
        if (-not $BootstrapScoop) {
            throw 'Scoop is not installed. Pass -BootstrapScoop to install it, or omit -UseScoop.'
        }
        Write-Step 'Scoop is missing; installing it into your user profile (no admin).'
        $bootstrap = Join-Path ([IO.Path]::GetTempPath()) 'scoop-bootstrap.ps1'
        Invoke-WebRequest -Uri 'https://get.scoop.sh' -OutFile $bootstrap -UseBasicParsing
        $shell = 'powershell.exe'
        if ($null -eq (Get-Command -Name 'powershell.exe' -ErrorAction SilentlyContinue)) { $shell = 'pwsh.exe' }
        $global:LASTEXITCODE = 0
        & $shell -NoProfile -ExecutionPolicy RemoteSigned -File $bootstrap
        Remove-Item -LiteralPath $bootstrap -Force -ErrorAction SilentlyContinue
        $shims = Join-Path $env:USERPROFILE 'scoop\shims'
        if ((Test-Path -LiteralPath $shims) -and -not (($env:Path -split ';') -contains $shims)) {
            $env:Path = "$shims;$env:Path"
        }
        $scoop = Get-Command -Name 'scoop' -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($null -eq $scoop) { throw 'Scoop could not be bootstrapped.' }
    }

    Write-Step 'Installing openssh with Scoop'
    $global:LASTEXITCODE = 0
    & scoop install openssh
    if ($LASTEXITCODE -ne 0) { throw "scoop install openssh failed with exit code $LASTEXITCODE." }

    $appDir = Get-ScoopOpenSshDir
    if ($null -eq $appDir) { throw 'Scoop reported success but the openssh app folder was not found.' }
    return $appDir
}

function Uninstall-ScoopCopy {
    # Safe only after the daemon files were copied out: the standalone copy is what runs.
    $appDir = Get-ScoopOpenSshDir
    if ($null -eq $appDir) {
        Write-Ok 'Scoop has no openssh copy to remove.'
        return
    }
    $scoop = Get-Command -Name 'scoop' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $scoop) {
        Write-Warn 'Scoop is no longer available; leaving its openssh folder untouched.'
        return
    }
    Write-Step 'Removing the Scoop copy of openssh (the standalone daemon copy stays)'
    $global:LASTEXITCODE = 0
    & scoop uninstall openssh
    if ($LASTEXITCODE -ne 0) {
        Write-Warn "scoop uninstall openssh exited with code $LASTEXITCODE; check it manually."
        return
    }
    Write-Ok 'Scoop copy removed'
}

function Write-SshdConfig {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][int]$Port,
        [Parameter(Mandatory)][string]$ConfigDir
    )

    $rsa = Join-Path $ConfigDir $script:KeyNames.Rsa
    $ed25519 = Join-Path $ConfigDir $script:KeyNames.Ed25519
    $authorized = Join-Path $env:USERPROFILE '.ssh\authorized_keys'

    $lines = @(
        '# Generated by Test-SshdHost.ps1 - user-mode sshd, no Windows service, no admin.',
        '# Listens on loopback only; change ListenAddress to 0.0.0.0 to accept LAN connections.',
        "Port $Port",
        'ListenAddress 127.0.0.1',
        'Protocol 2',
        '',
        "# Host keys live next to this file.",
        "HostKey `"$ed25519`"",
        "HostKey `"$rsa`"",
        '',
        '# Logging goes to the file given by -E on the command line: Win32-OpenSSH does not',
        '# accept a "LogFile" keyword here (it fails with "Bad configuration option: LogFile").',
        'LogLevel VERBOSE',
        'LoginGraceTime 60',
        'MaxAuthTries 6',
        'MaxSessions 10',
        '',
        '# A user-mode sshd cannot read logon events, so password login is not offered;',
        '# key-based login is the supported path.',
        'PasswordAuthentication no',
        'PermitEmptyPasswords no',
        'KbdInteractiveAuthentication no',
        'ChallengeResponseAuthentication no',
        'PubkeyAuthentication yes',
        '# Absolute per-user key file; the stock config uses a ProgramData path that a',
        '# non-admin sshd must not need.',
        "AuthorizedKeysFile `"$authorized`"",
        'StrictModes no',
        '',
        'AllowTcpForwarding yes',
        'AllowAgentForwarding no',
        'X11Forwarding no',
        'PermitTunnel no',
        'GatewayPorts no',
        'PermitUserEnvironment no',
        'Subsystem sftp sftp-server.exe'
    )
    $lines -join "`r`n" | Set-Content -LiteralPath $Path -Encoding ASCII
}

function Initialize-HostKey {
    param(
        [Parameter(Mandatory)][string]$KeyGenPath,
        [Parameter(Mandatory)][string]$KeyPath,
        [Parameter(Mandatory)][string]$KeyType
    )

    if (Test-Path -LiteralPath $KeyPath) {
        Write-Ok "Host key already present: $KeyPath"
        return
    }
    Initialize-KeyPair -KeyGenPath $KeyGenPath -KeyPath $KeyPath -KeyType $KeyType
    Write-Ok "Generated host key $KeyPath"
}

function Get-NextFreePort {
    # Returns the first port at or above $StartPort that nothing accepts connections on.
    param(
        [Parameter(Mandatory)][int]$StartPort,
        [int]$MaxTries = 50
    )

    for ($candidate = $StartPort; $candidate -lt ($StartPort + $MaxTries); $candidate++) {
        if ($candidate -gt 65535) { break }
        $client = New-Object System.Net.Sockets.TcpClient
        try {
            $connect = $client.ConnectAsync('127.0.0.1', $candidate)
            $inUse = ($connect.Wait(250) -and $client.Connected)
        } catch {
            $inUse = $false
        } finally {
            $client.Dispose()
        }
        if (-not $inUse) { return $candidate }
    }
    throw "No free port found at or above $StartPort."
}

function Test-LocalPortListening {
    param(
        [string]$ComputerName = '127.0.0.1',
        [Parameter(Mandatory)][int]$Port,
        [int]$TimeoutMs = 700
    )

    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $connect = $client.ConnectAsync($ComputerName, $Port)
        if (-not $connect.Wait($TimeoutMs)) { return $false }
        return $client.Connected
    } catch {
        return $false
    } finally {
        $client.Dispose()
    }
}

function Get-TrustedKeyPath {
    # Resolves trusted-keys.txt next to this script.
    #
    # $PSScriptRoot is empty when the script is dot-sourced, dot-invoked or run through
    # "-Command", so fall back to the invocation path and then the current directory. Checking
    # each candidate keeps a "silently finds no keys" failure from looking like a permissions bug.
    $candidates = New-Object System.Collections.Generic.List[string]

    if (-not [string]::IsNullOrWhiteSpace($PSScriptRoot)) {
        $candidates.Add((Join-Path $PSScriptRoot 'trusted-keys.txt'))
    }
    if ($PSCommandPath) {
        $candidates.Add((Join-Path (Split-Path -Parent $PSCommandPath) 'trusted-keys.txt'))
    }
    if ($MyInvocation.MyCommand.Path) {
        $candidates.Add((Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'trusted-keys.txt'))
    }
    $candidates.Add((Join-Path (Get-Location).Path 'trusted-keys.txt'))

    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    }
    return $null
}

function Get-TrustedKey {
    # Reads trusted-keys.txt from the folder holding this script. Public keys only, so the file
    # is safe to keep next to the scripts; a missing file simply yields nothing.
    $path = Get-TrustedKeyPath
    if ($null -eq $path) { return @() }

    $keys = @(Get-Content -LiteralPath $path |
        Where-Object { $_ -notmatch '^\s*#' } |
        Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ -match '^(ssh-(rsa|ed25519)|ecdsa-sha2-nistp|sk-ssh-)' })
    return $keys
}

function Install-AuthorizedKey {
    param(
        [Parameter(Mandatory)][string]$PublicKey,
        [string]$Target = (Join-Path $env:USERPROFILE '.ssh'),
        [string]$RecordFile
    )

    $text = $PublicKey.Trim()
    if (Test-Path -LiteralPath $PublicKey -PathType Leaf) {
        $text = (Get-Content -LiteralPath $PublicKey -Raw).Trim()
    }
    if ($text -notmatch '^(ssh-(rsa|ed25519)|ecdsa-sha2-nistp|sk-ssh-)') {
        throw 'That does not look like an SSH public key (expected ssh-ed25519 / ssh-rsa / ecdsa-...).'
    }

    New-Item -ItemType Directory -Path $Target -Force | Out-Null
    $file = Join-Path $Target 'authorized_keys'
    $existing = @()
    if (Test-Path -LiteralPath $file) {
        $existing = @(Get-Content -LiteralPath $file | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    }
    if ($existing -contains $text) {
        Write-Ok "That key is already authorized in $file"
    } else {
        ($existing + $text) -join "`r`n" | Set-Content -LiteralPath $file -Encoding ASCII
        Write-Ok "Authorized key added to $file"
    }

    # Record it so Uninstall-SshdHost.ps1 can remove exactly this key again.
    if (-not [string]::IsNullOrWhiteSpace($RecordFile)) {
        $recorded = @()
        if (Test-Path -LiteralPath $RecordFile) {
            $recorded = @(Get-Content -LiteralPath $RecordFile | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
        }
        if (-not ($recorded -contains $text)) {
            ($recorded + $text) -join "`r`n" | Set-Content -LiteralPath $RecordFile -Encoding ASCII
        }
    }
}


function Invoke-SshdHost {
    param(
        [int]$Port,
        [string]$AddAuthorizedKey,
        [switch]$NoTrustedKeysFile,
        [switch]$GenerateClientKey,
        [switch]$UseScoop,
        [switch]$BootstrapScoop,
        [switch]$Start,
        [string]$OpenSshSource
    )

    Test-SshdHostPrereq

    Write-Host ''
    Write-Host ' user-mode SSH host (Win32-OpenSSH), no admin required' -ForegroundColor White
    Write-Host ' ------------------------------------------------------' -ForegroundColor DarkGray
    Write-Info "Install folder: $script:SshHostDir"
    Write-Info "Config folder : $script:SshConfigDir"

    # ---- 0. stop a stale sshd that still holds our binaries open ----
    # A user-mode sshd we started earlier keeps sshd.exe (and sshd-session.exe / sshd-auth.exe /
    # ssh-shellhost.exe) open, so copying fresh files over them on a re-run fails with "being used
    # by another process". Stop only processes whose image lives in our own install folder, so a
    # Windows system sshd service or any unrelated sshd is left alone. Any live connection through
    # our sshd drops here, which is expected when reinstalling or reconfiguring.
    if (Test-Path -LiteralPath $script:SshHostDir) {
        $ourDir = (Resolve-Path -LiteralPath $script:SshHostDir).Path
        $ourPrefix = $ourDir.TrimEnd('\') + '\'
        $running = @(Get-Process -Name 'sshd', 'sshd-session', 'sshd-auth', 'ssh-shellhost', 'ssh-agent' -ErrorAction SilentlyContinue)
        foreach ($proc in $running) {
            $procPath = $null
            try { $procPath = $proc.Path } catch { $procPath = $null }
            if ([string]::IsNullOrWhiteSpace($procPath)) { continue }
            if ($procPath.StartsWith($ourPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
                Write-Step "Stopping a running sshd from this folder (PID $($proc.Id)) so its files can be replaced"
                try {
                    $proc.Kill()
                    $null = $proc.WaitForExit(5000)
                } catch {
                    Write-Warn "Could not stop PID $($proc.Id): $($_.Exception.Message)"
                }
            }
        }
        # Windows releases the executable's file handle a moment after the process exits.
        Start-Sleep -Milliseconds 400
    }

    # ---- 1. choose where the daemon files come from ----
    $source = $null
    if (-not [string]::IsNullOrWhiteSpace($OpenSshSource)) {
        $source = $OpenSshSource
        Write-Step "Using the OpenSSH folder you supplied: $source"
        Copy-OpenSshRuntime -Source $source -Target $script:SshHostDir
    } elseif ($null -ne (Get-SystemOpenSshDir)) {
        $source = Get-SystemOpenSshDir
        Write-Ok "Using the OpenSSH that ships with Windows: $source"
        Copy-OpenSshRuntime -Source $source -Target $script:SshHostDir
    } elseif ($UseScoop) {
        $copied = Install-OpenSshViaScoop -BootstrapScoop:$BootstrapScoop
        Copy-OpenSshRuntime -Source $copied -Target $script:SshHostDir
        Write-Ok "Copied the daemon files into $script:SshHostDir"
        Uninstall-ScoopCopy
    } elseif ($null -ne (Get-ScoopOpenSshDir)) {
        $source = Get-ScoopOpenSshDir
        Write-Ok "Using the existing Scoop install: $source"
        Copy-OpenSshRuntime -Source $source -Target $script:SshHostDir
    } else {
        Save-OpenSshSource -TargetDir $script:SshHostDir
    }

    $sshd = Join-Path $script:SshHostDir $script:HostExeName
    $keygen = Join-Path $script:SshHostDir 'ssh-keygen.exe'
    if (-not (Test-Path -LiteralPath $sshd -PathType Leaf)) {
        throw "sshd.exe is missing from $script:SshHostDir."
    }
    if (-not (Test-Path -LiteralPath $keygen -PathType Leaf)) {
        throw "ssh-keygen.exe is missing from $script:SshHostDir (needed to create host keys)."
    }

    # ---- 2. configuration and host keys ----
    New-Item -ItemType Directory -Path $script:SshConfigDir -Force | Out-Null
    Initialize-HostKey -KeyGenPath $keygen -KeyPath (Join-Path $script:SshConfigDir $script:KeyNames.Ed25519) -KeyType 'ed25519'
    Initialize-HostKey -KeyGenPath $keygen -KeyPath (Join-Path $script:SshConfigDir $script:KeyNames.Rsa) -KeyType 'rsa'

    $logFile = Join-Path $script:SshConfigDir 'sshd.log'
    $configFile = Join-Path $script:SshConfigDir 'sshd_config'
    Write-SshdConfig -Path $configFile -Port $Port -ConfigDir $script:SshConfigDir
    Write-Ok "Wrote $configFile"

    $recordFile = Join-Path $script:SshConfigDir 'authorized-keys.txt'

    if (-not $NoTrustedKeysFile) {
        $trusted = @(Get-TrustedKey)
        if ($trusted.Count -gt 0) {
            Write-Step "Authorizing $($trusted.Count) key(s) from trusted-keys.txt"
            foreach ($key in $trusted) {
                Install-AuthorizedKey -PublicKey $key -RecordFile $recordFile
            }
        } else {
            Write-Info 'No trusted-keys.txt entries found; use -AddAuthorizedKey to add one.'
        }
    }

    if (-not [string]::IsNullOrWhiteSpace($AddAuthorizedKey)) {
        Install-AuthorizedKey -PublicKey $AddAuthorizedKey -RecordFile $recordFile
    }
    if ($GenerateClientKey) {
        $clientDir = Join-Path $script:SshConfigDir 'client'
        New-Item -ItemType Directory -Path $clientDir -Force | Out-Null
        $clientKey = Join-Path $clientDir 'id_ed25519'
        if (-not (Test-Path -LiteralPath $clientKey)) {
            Initialize-KeyPair -KeyGenPath $keygen -KeyPath $clientKey -KeyType 'ed25519'
            if (-not (Test-Path -LiteralPath $clientKey)) { throw 'ssh-keygen failed to create the client key.' }
        }
        Install-AuthorizedKey -PublicKey "$clientKey.pub" -RecordFile $recordFile
        Write-Info "Client private key: $clientKey (copy it to the client, keep it secret)"
    }

    # ---- 3. start and verify ----
    if (-not $Start) {
        Write-Host ''
        Write-Host ' Configured. Start it with:' -ForegroundColor White
        Write-Host "     & `"$sshd`" -f `"$configFile`" -E `"$logFile`"" -ForegroundColor Gray
        Write-Host ''
        return
    }

    if (Test-LocalPortListening -Port $Port) {
        Write-Warn "Something is already listening on port $Port; not starting a second sshd."
    } else {
        Write-Step "Starting sshd on 127.0.0.1:$Port"
        $process = Start-Process -FilePath $sshd -ArgumentList @('-f', $configFile, '-E', $logFile) -WindowStyle Hidden -PassThru
        $listening = $false
        for ($attempt = 0; $attempt -lt 24; $attempt++) {
            Start-Sleep -Milliseconds 250
            if ($process.HasExited) { break }
            if (Test-LocalPortListening -Port $Port) { $listening = $true; break }
        }
        if (-not $listening) {
            $detail = ''
            if (Test-Path -LiteralPath $logFile) { $detail = (Get-Content -LiteralPath $logFile -Tail 5) -join ' | ' }
            throw "sshd did not start listening on port $Port. Log: $detail"
        }
        Write-Ok "sshd is listening on port $Port (PID $($process.Id))"
    }

    Write-Host ''
    Write-Host ' Remote login is ready:' -ForegroundColor White
    Write-Host "     ssh -p $Port $env:USERNAME@127.0.0.1" -ForegroundColor Gray
    Write-Info 'Loopback only for now: it is not reachable from other machines until you allow it.'
    Write-Host ''
    Write-Host ' Remove it later with: .\Uninstall-Tools.ps1 -Sshd' -ForegroundColor Gray
    Write-Host ''
}



try {
    Invoke-SshdHost -Port $Port -AddAuthorizedKey $AddAuthorizedKey -NoTrustedKeysFile:$NoTrustedKeysFile -GenerateClientKey:$GenerateClientKey `
        -UseScoop:$UseScoop -BootstrapScoop:$BootstrapScoop -Start:$Start -OpenSshSource $OpenSshSource
} catch {
    Write-Host ''
    Write-Host "[error] $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
