<#
.SYNOPSIS
    Removes cloudflared and/or the user-mode SSH host created by Install-Tools.ps1.
    No administrator rights are needed.

.DESCRIPTION
    One remover for both no-admin tools in this folder. Select the parts with -Cloudflared
    and/or -Sshd; by default every part that is actually present is removed.

    cloudflared part
      * Stops running cloudflared processes so files are not locked.
      * Deletes %LOCALAPPDATA%\cloudflared and removes that folder from the per-user PATH
        (HKCU\Environment, never the machine PATH), or uninstalls the Scoop package.
      * Deletes %USERPROFILE%\.cloudflared (certificate and tunnel credentials) by default;
        -KeepCredentials keeps them for a quick reinstall.
      * Reports machine-wide or winget installs instead of touching them.

    SSH host part
      * Stops the user-mode sshd.
      * Deletes %LOCALAPPDATA%\openssh-host and %USERPROFILE%\.ssh-host (config + host keys).
      * Revokes only the keys it added to .ssh\authorized_keys; other keys stay.
      * Never touches the OpenSSH that ships with Windows or any Windows service.

.PARAMETER Cloudflared
    Remove the cloudflared part.

.PARAMETER Sshd
    Remove the SSH host part.

.PARAMETER Force
    Do not ask for confirmation.

.PARAMETER DryRun
    Show what would be stopped and deleted, and change nothing.

.PARAMETER KeepCredentials
    Keep %USERPROFILE%\.cloudflared instead of deleting it.

.PARAMETER KeepAuthorizedKeys
    Leave .ssh\authorized_keys untouched.

.PARAMETER Playit
    Also remove the playit.gg agent from %LOCALAPPDATA%\playit (stopping it first). The agent's
    claimed identity lives in %PROGRAMDATA%\playit_gg if a service install created it; that is
    left alone because it is shared state, not something this script created.

.PARAMETER InstallDir
    cloudflared folder. Default %LOCALAPPDATA%\cloudflared.

.PARAMETER SshHostDir
    sshd folder. Default %LOCALAPPDATA%\openssh-host.

.PARAMETER SshConfigDir
    sshd config folder. Default %USERPROFILE%\.ssh-host.

.EXAMPLE
    .\Uninstall-Tools.ps1 -DryRun

.EXAMPLE
    .\Uninstall-Tools.ps1 -Sshd

.EXAMPLE
    .\Uninstall-Tools.ps1 -Force -KeepCredentials -KeepAuthorizedKeys

.NOTES
    If script execution is still refused, allow it once for your own account (no admin):

        Get-ChildItem -Path .\*.ps1 | Unblock-File
        Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
#>
[CmdletBinding()]
param(
    [switch]$Cloudflared,

    [switch]$Sshd,

    [switch]$Force,

    [switch]$DryRun,

    [switch]$KeepCredentials,

    [switch]$KeepAuthorizedKeys,

    [switch]$Playit,

    [string]$InstallDir,

    [string]$PlayitDir,

    [string]$SshHostDir,

    [string]$SshConfigDir
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

# cloudflared-side state
$script:ExeName = 'cloudflared.exe'
$script:InstallDir     = $InstallDir
$script:ScoopShims     = $null
$script:ScoopAppdir    = $null
$script:CredDir        = $null
$script:ScoopAppFolder = $null

# SSH-side state
$script:HostExeName = 'sshd.exe'
$script:PlayitDir = $PlayitDir
$script:SshHostDir  = $SshHostDir
$script:SshConfigDir = $SshConfigDir

# ---------------------------------------------------------------------------
# Prerequisites
# ---------------------------------------------------------------------------
function Test-CloudflaredUninstallPrereq {
    if (-not [string]::IsNullOrWhiteSpace($env:LOCALAPPDATA) -and [string]::IsNullOrWhiteSpace($script:InstallDir)) {
        $script:InstallDir = Join-Path $env:LOCALAPPDATA 'cloudflared'
    }
    if (-not [string]::IsNullOrWhiteSpace($env:USERPROFILE)) {
        $script:ScoopShims  = Join-Path $env:USERPROFILE 'scoop\shims'
        $script:ScoopAppdir = Join-Path $env:USERPROFILE 'scoop\apps\cloudflared'
        $script:CredDir     = Join-Path $env:USERPROFILE '.cloudflared'
    }

    # $IsWindows is undefined on Windows PowerShell 5.1, so only trust it when present.
    $isWindowsHost = $true
    if ($null -ne $IsWindows) { $isWindowsHost = [bool]$IsWindows }
    if (-not $isWindowsHost) {
        throw 'This script targets Windows. On other platforms uninstall cloudflared with your package manager.'
    }
    if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
        throw 'LOCALAPPDATA is not set, so the per-user install location cannot be resolved from this shell.'
    }
    if ([string]::IsNullOrWhiteSpace($env:USERPROFILE)) {
        throw 'USERPROFILE is not set, so the Scoop and credential locations cannot be resolved from this shell.'
    }
}

# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------
function Write-Step {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Write-Ok {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "[ ok ] $Message" -ForegroundColor Green
}

function Write-Warn {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "[warn] $Message" -ForegroundColor Yellow
}

function Write-Info {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "     $Message" -ForegroundColor Gray
}

# ---------------------------------------------------------------------------
# PATH value helpers (pure where possible, so the logic is easy to reason about)
# ---------------------------------------------------------------------------
function Get-PathValueWithoutEntry {
    # Returns the PATH string with every occurrence of $Dir removed.
    param(
        [string]$PathValue,
        [Parameter(Mandatory)][string]$Dir
    )

    if ([string]::IsNullOrWhiteSpace($PathValue)) { return '' }

    $target = $Dir.TrimEnd('\')
    $kept = New-Object System.Collections.Generic.List[string]
    foreach ($entry in ($PathValue -split ';')) {
        if ([string]::IsNullOrWhiteSpace($entry)) { continue }
        if ($entry.Trim().TrimEnd('\') -ieq $target) { continue }
        $kept.Add($entry.Trim())
    }
    return ($kept -join ';')
}

function Get-PathValueHasEntry {
    param(
        [string]$PathValue,
        [Parameter(Mandatory)][string]$Dir
    )

    if ([string]::IsNullOrWhiteSpace($PathValue)) { return $false }

    $target = $Dir.TrimEnd('\')
    foreach ($entry in ($PathValue -split ';')) {
        if ([string]::IsNullOrWhiteSpace($entry)) { continue }
        if ($entry.Trim().TrimEnd('\') -ieq $target) { return $true }
    }
    return $false
}

function Get-UserPathValue {
    try {
        return [Environment]::GetEnvironmentVariable('Path', 'User')
    } catch {
        return $null
    }
}

function Send-EnvironmentChange {
    # Explorer only reloads the user environment when it receives WM_SETTINGCHANGE, so
    # without this the next terminal can still see the removed folder on PATH.
    try {
        if (-not ('Win32.EnvironmentBroadcast' -as [type])) {
            Add-Type -Namespace Win32 -Name EnvironmentBroadcast -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true, CharSet = System.Runtime.InteropServices.CharSet.Auto)]
public static extern System.IntPtr SendMessageTimeout(System.IntPtr hWnd, uint Msg, System.UIntPtr wParam, string lParam, uint fuFlags, uint uTimeout, out System.UIntPtr lpdwResult);
'@
        }
        $result = [UIntPtr]::Zero
        [void][Win32.EnvironmentBroadcast]::SendMessageTimeout([IntPtr]0xffff, 0x001A, [UIntPtr]::Zero, 'Environment', 2, 5000, [ref]$result)
    } catch {
        $null = $_   # best effort; new sessions pick the change up on the next sign-in
    }
}

function Write-UserPathValue {
    param([Parameter(Mandatory)][AllowEmptyString()][string]$Value)

    try {
        $key = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Environment', $true)
        if ($null -ne $key) {
            try {
                $kind = $key.GetValueKind('Path')
            } catch {
                $kind = [Microsoft.Win32.RegistryValueKind]::ExpandString
            }
            $key.SetValue('Path', $Value, $kind)
            $key.Close()
        }
    } catch {
        $null = $_   # fall through to the .NET API below
    }

    $current = Get-UserPathValue
    if ($null -eq $current -or ($current.Trim() -ne $Value.Trim())) {
        try {
            [Environment]::SetEnvironmentVariable('Path', $Value, 'User')
        } catch {
            $null = $_
        }
    }

    Send-EnvironmentChange

    $check = Get-UserPathValue
    if ($null -eq $check) { return $false }
    return ($check.Trim() -eq $Value.Trim())
}

function Revoke-UserPathEntry {
    param(
        [Parameter(Mandatory)][string]$Dir,
        [switch]$DryRun
    )

    $userPath = Get-UserPathValue
    if (-not (Get-PathValueHasEntry -PathValue $userPath -Dir $Dir)) {
        Write-Ok "User PATH does not contain $Dir"
        return $true
    }

    $newPath = Get-PathValueWithoutEntry -PathValue $userPath -Dir $Dir

    if ($DryRun) {
        Write-Step "Would remove from user PATH: $Dir"
        return $true
    }

    $ok = Write-UserPathValue -Value $newPath
    if ($ok) {
        Write-Ok "Removed from user PATH: $Dir"
    } else {
        Write-Warn "Could not update the user PATH; remove this folder yourself: $Dir"
    }
    return $ok
}

# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------
function Get-CloudflaredCandidatePath {
    $paths = New-Object System.Collections.Generic.List[string]
    if ($script:InstallDir) {
        $paths.Add((Join-Path $script:InstallDir $script:ExeName))
    }
    if ($env:LOCALAPPDATA) {
        $paths.Add((Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links\cloudflared.exe'))
    }
    if ($script:ScoopShims) {
        $paths.Add((Join-Path $script:ScoopShims $script:ExeName))
    }
    if ($script:ScoopAppdir) {
        $paths.Add((Join-Path $script:ScoopAppdir "current\$($script:ExeName)"))
    }
    if ($env:ProgramFiles) {
        $paths.Add((Join-Path $env:ProgramFiles 'cloudflared\cloudflared.exe'))
    }
    if (${env:ProgramFiles(x86)}) {
        $paths.Add((Join-Path ${env:ProgramFiles(x86)} 'cloudflared\cloudflared.exe'))
    }
    return $paths.ToArray()
}

function Get-CloudflaredOnPath {
    $command = Get-Command -Name 'cloudflared' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $command) { return $null }
    if ($command.PSObject.Properties['Path'] -and $command.Path) { return $command.Path }
    if ($command.Source) { return $command.Source }
    return $null
}

function Find-CloudflaredTarget {
    # Returns one record per removable install: Kind is 'Scoop' or 'Manual'.
    # Installs this script must not touch (Program Files, winget, unknown paths) are
    # reported separately so the summary can explain them.
    $targets = New-Object System.Collections.Generic.List[object]
    $notices = New-Object System.Collections.Generic.List[object]

    if ($script:ScoopAppdir -and (Test-Path -LiteralPath $script:ScoopAppdir)) {
        $shim = Join-Path $script:ScoopShims $script:ExeName
        $targets.Add([pscustomobject]@{
            Kind = 'Scoop'
            Dir  = $script:ScoopAppdir
            Path = $shim
        })
    }

    # An existing folder counts even without the exe, so a half-removed install is
    # cleaned up too.
    if ($script:InstallDir -and (Test-Path -LiteralPath $script:InstallDir)) {
        $targets.Add([pscustomobject]@{
            Kind = 'Manual'
            Dir  = $script:InstallDir
            Path = (Join-Path $script:InstallDir $script:ExeName)
        })
    }

    $wingetLink = $null
    if ($env:LOCALAPPDATA) {
        $wingetLink = Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links\cloudflared.exe'
    }
    if ($wingetLink -and (Test-Path -LiteralPath $wingetLink)) {
        $notices.Add([pscustomobject]@{
            Reason = 'Looks like a winget-managed install'
            Path   = $wingetLink
            Hint   = 'winget uninstall --id Cloudflare.cloudflared'
        })
    }

    foreach ($programFiles in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if ([string]::IsNullOrWhiteSpace($programFiles)) { continue }
        $machinePath = Join-Path $programFiles 'cloudflared\cloudflared.exe'
        if (Test-Path -LiteralPath $machinePath) {
            $notices.Add([pscustomobject]@{
                Reason = 'Machine-wide install, needs an elevated shell'
                Path   = $machinePath
                Hint   = 'Remove it from an Administrator prompt (or its MSI/service uninstaller)'
            })
        }
    }

    $onPath = Get-CloudflaredOnPath
    if ($onPath) {
        $known = @()
        if ($script:InstallDir) { $known += $script:InstallDir }
        if ($script:ScoopAppdir) { $known += $script:ScoopAppdir }
        if ($script:ScoopShims) { $known += $script:ScoopShims }

        $isKnown = $false
        foreach ($dir in $known) {
            if ($onPath.TrimEnd('\').StartsWith($dir.TrimEnd('\'), [System.StringComparison]::OrdinalIgnoreCase)) {
                $isKnown = $true
                break
            }
        }
        if (-not $isKnown) {
            $notices.Add([pscustomobject]@{
                Reason = 'cloudflared is on PATH from a location this script does not manage'
                Path   = $onPath
                Hint   = 'Delete it manually or uninstall it with the tool that installed it'
            })
        }
    }

    return [pscustomobject]@{
        Targets = $targets.ToArray()
        Notices = $notices.ToArray()
    }
}

# ---------------------------------------------------------------------------
# Running processes
# ---------------------------------------------------------------------------
function Get-CloudflaredProcess {
    try {
        return @(Get-Process -Name 'cloudflared' -ErrorAction SilentlyContinue)
    } catch {
        return @()
    }
}

function Get-CloudflaredService {
    try {
        return (Get-Service -Name 'cloudflared' -ErrorAction SilentlyContinue | Select-Object -First 1)
    } catch {
        return $null
    }
}

# ---------------------------------------------------------------------------
# Removal
# ---------------------------------------------------------------------------
function Confirm-Action {
    param(
        [Parameter(Mandatory)][string]$Question,
        [switch]$Force
    )

    if ($Force) { return $true }
    if (-not [Environment]::UserInteractive) {
        Write-Warn 'Not interactive, so nothing was changed. Re-run with -Force to uninstall unattended.'
        return $false
    }
    $answer = Read-Host "$Question [y/N]"
    return ($answer -match '^(y|yes)$')
}

function Uninstall-CloudflaredScoop {
    param(
        [Parameter(Mandatory)][pscustomobject]$Target,
        [switch]$DryRun
    )

    $scoop = Get-Command -Name 'scoop' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $scoop) {
        Write-Warn 'Scoop is not available, so the Scoop app is removed directly instead of via "scoop uninstall".'
    } else {
        Write-Step 'Running: scoop uninstall cloudflared'
        if ($DryRun) {
            Write-Info "(dry run) would run: scoop uninstall cloudflared"
        } else {
            $global:LASTEXITCODE = 0
            $previousErrorAction = $ErrorActionPreference
            $ErrorActionPreference = 'Continue'
            try {
                & scoop uninstall cloudflared
            } catch {
                Write-Warn "scoop uninstall failed: $($_.Exception.Message)"
            } finally {
                $ErrorActionPreference = $previousErrorAction
            }
            if ($LASTEXITCODE -ne 0) {
                Write-Warn "scoop uninstall exited with code $LASTEXITCODE; cleaning the folder directly."
            }
        }
    }

    # Whatever scoop did (or could not do), make sure the app folder and shims are gone.
    if (Test-Path -LiteralPath $Target.Dir) {
        if ($DryRun) {
            Write-Step "Would delete folder: $($Target.Dir)"
        } else {
            Write-Step "Deleting folder: $($Target.Dir)"
            try {
                Remove-Item -LiteralPath $Target.Dir -Recurse -Force
                Write-Ok "Deleted $($Target.Dir)"
            } catch {
                Write-Warn "Could not delete $($Target.Dir): $($_.Exception.Message)"
                return $false
            }
        }
    }

    foreach ($shimName in @($script:ExeName, "cloudflared.shim", "cloudflared.ps1")) {
        $shim = Join-Path $script:ScoopShims $shimName
        if (-not (Test-Path -LiteralPath $shim)) { continue }
        if ($DryRun) {
            Write-Step "Would delete shim: $shim"
        } else {
            try {
                Remove-Item -LiteralPath $shim -Force
                Write-Ok "Deleted $shim"
            } catch {
                Write-Warn "Could not delete $shim : $($_.Exception.Message)"
            }
        }
    }

    return $true
}

function Uninstall-CloudflaredManual {
    param(
        [Parameter(Mandatory)][pscustomobject]$Target,
        [switch]$DryRun
    )

    if (Test-Path -LiteralPath $Target.Dir) {
        if ($DryRun) {
            Write-Step "Would delete folder: $($Target.Dir)"
        } else {
            Write-Step "Deleting folder: $($Target.Dir)"
            try {
                Remove-Item -LiteralPath $Target.Dir -Recurse -Force
                Write-Ok "Deleted $($Target.Dir)"
            } catch {
                Write-Warn "Could not delete $($Target.Dir): $($_.Exception.Message)"
                Write-Info 'If the file is in use, close that program and rerun the script.'
                return $false
            }
        }
    }

    return (Revoke-UserPathEntry -Dir $Target.Dir -DryRun:$DryRun)
}

# ---------------------------------------------------------------------------
# Main flow
# ---------------------------------------------------------------------------

function Test-SshdUninstallPrereq {
    if (-not [string]::IsNullOrWhiteSpace($env:LOCALAPPDATA) -and [string]::IsNullOrWhiteSpace($script:SshHostDir)) {
        $script:SshHostDir = Join-Path $env:LOCALAPPDATA 'openssh-host'
    }
    if (-not [string]::IsNullOrWhiteSpace($env:USERPROFILE) -and [string]::IsNullOrWhiteSpace($script:SshConfigDir)) {
        $script:SshConfigDir = Join-Path $env:USERPROFILE '.ssh-host'
    }
    $isWindowsHost = $true
    if ($null -ne $IsWindows) { $isWindowsHost = [bool]$IsWindows }
    if (-not $isWindowsHost) { throw 'This script targets Windows.' }
    if ([string]::IsNullOrWhiteSpace($env:USERPROFILE)) { throw 'USERPROFILE is not set.' }
}

function Get-SshdHostProcess {
    try {
        return @(Get-Process -Name 'sshd' -ErrorAction SilentlyContinue)
    } catch {
        return @()
    }
}

function Get-ListenerPort {
    # Ports this script's sshd listens on, read from the generated config.
    param([Parameter(Mandatory)][string]$ConfigPath)

    $ports = @()
    if (-not (Test-Path -LiteralPath $ConfigPath)) { return $ports }
    foreach ($line in (Get-Content -LiteralPath $ConfigPath)) {
        if ($line -match '^\s*Port\s+(\d+)') { $ports += [int]$Matches[1] }
    }
    return $ports
}

function Revoke-AuthorizedKeyLine {
    # Removes keys that were added for this host; unrelated keys in the file are kept.
    param(
        [Parameter(Mandatory)][string]$KeyFile,
        [string[]]$KeysToRemove,
        [switch]$DryRun
    )

    if (-not (Test-Path -LiteralPath $KeyFile)) { return $true }
    if (-not $KeysToRemove -or $KeysToRemove.Count -eq 0) {
        Write-Info "No generated keys to remove from $KeyFile"
        return $true
    }

    $lines = @(Get-Content -LiteralPath $KeyFile)
    $kept = @($lines | Where-Object { $line = $_.Trim(); -not ($KeysToRemove -contains $line) })
    if ($kept.Count -eq $lines.Count) {
        Write-Info "Generated keys are not in $KeyFile; nothing to remove"
        return $true
    }

    if ($DryRun) {
        Write-Step "Would remove $($lines.Count - $kept.Count) key line(s) from $KeyFile"
        return $true
    }

    try {
        if ($kept.Count -eq 0) {
            Remove-Item -LiteralPath $KeyFile -Force
            Write-Ok "Removed $KeyFile (it only held this host's key)"
        } else {
            $kept -join "`r`n" | Set-Content -LiteralPath $KeyFile -Encoding ASCII
            Write-Ok "Removed this host's key from $KeyFile ($($kept.Count) other key(s) kept)"
        }
        return $true
    } catch {
        Write-Warn "Could not update ${KeyFile}: $($_.Exception.Message)"
        return $false
    }
}

function Test-CanPrompt {
    # [Environment]::UserInteractive stays true for hosts without a usable stdin, so also
    # require a real input stream before asking a question.
    if (-not [Environment]::UserInteractive) { return $false }
    try {
        if ($null -eq $Host.UI) { return $false }
        if ($null -eq [Console]::In) { return $false }
    } catch {
        return $false
    }
    return $true
}


function Invoke-UninstallCloudflared {
    param(
        [switch]$Force,
        [switch]$DryRun,
        [switch]$KeepCredentials
    )

    $removeCredentials = -not $KeepCredentials

    Test-CloudflaredUninstallPrereq

    Write-Host ''
    Write-Host ' cloudflared uninstaller for Windows (no admin required)' -ForegroundColor White
    Write-Host ' -------------------------------------------------------' -ForegroundColor DarkGray
    if ($DryRun) {
        Write-Host ' Dry run: nothing will be changed.' -ForegroundColor Yellow
    }

    $found = Find-CloudflaredTarget
    $targets = @($found.Targets)
    $notices = @($found.Notices)

    foreach ($notice in $notices) {
        Write-Warn "$($notice.Reason): $($notice.Path)"
        Write-Host "        $($notice.Hint)" -ForegroundColor Gray
    }

    if ($targets.Count -eq 0) {
        Write-Host ''
        Write-Ok 'No cloudflared installation created by Install-Cloudflared.ps1 was found.'
        # A stale PATH entry is a common leftover, so tidy it even without an install.
        if (Get-PathValueHasEntry -PathValue (Get-UserPathValue) -Dir $script:InstallDir) {
            [void](Revoke-UserPathEntry -Dir $script:InstallDir -DryRun:$DryRun)
        }
        if (Test-Path -LiteralPath $script:CredDir) {
            Write-Host ''
            if ($removeCredentials) {
                if ($DryRun) {
                    Write-Step "Would delete credentials: $($script:CredDir)"
                } else {
                    Write-Step "Deleting credentials: $($script:CredDir)"
                    try {
                        Remove-Item -LiteralPath $script:CredDir -Recurse -Force
                        Write-Ok 'Deleted credential folder'
                    } catch {
                        Write-Warn "Could not delete $($script:CredDir): $($_.Exception.Message)"
                    }
                }
            } else {
                Write-Info "Credentials kept as requested: $($script:CredDir)"
            }
        }
        Write-Host ''
        return
    }

    Write-Host ''
    Write-Step 'Found the following installation(s):'
    foreach ($target in $targets) {
        Write-Host "     [$($target.Kind)] $($target.Dir)" -ForegroundColor White
    }

    if (Test-Path -LiteralPath $script:CredDir) {
        if ($removeCredentials) {
            Write-Info "Authorization files in $($script:CredDir) will be deleted too (use -KeepCredentials to keep them)."
        } else {
            Write-Info "Authorization files in $($script:CredDir) will be kept (-KeepCredentials)."
        }
    }

    $processes = @(Get-CloudflaredProcess)
    $service = Get-CloudflaredService
    if ($service) {
        Write-Host ''
        Write-Warn "A Windows service named 'cloudflared' exists ($($service.Status)). Removing it needs an elevated shell:"
        Write-Host '        cloudflared service uninstall      (or: sc.exe delete cloudflared)' -ForegroundColor Gray
        Write-Host '        The script can still remove the user-level copy below.' -ForegroundColor Gray
    }
    if ($processes.Count -gt 0) {
        $pids = ($processes | ForEach-Object { $_.Id }) -join ', '
        Write-Host ''
        Write-Warn "cloudflared is currently running (PID: $pids)."
        if (-not $DryRun) {
            if (Confirm-Action -Question 'Stop these processes so the files can be deleted?' -Force:$Force) {
                foreach ($process in $processes) {
                    try {
                        Stop-Process -Id $process.Id -Force -ErrorAction Stop
                        Write-Ok "Stopped process $($process.Id)"
                    } catch {
                        Write-Warn "Could not stop process $($process.Id): $($_.Exception.Message)"
                    }
                }
            } else {
                Write-Warn 'Continuing without stopping them; removing the executable may fail while it runs.'
            }
        }
    }

    if (-not $DryRun) {
        if (-not (Confirm-Action -Question 'Uninstall cloudflared now?' -Force:$Force)) {
            Write-Host ''
            Write-Host ' Cancelled. Nothing was changed.' -ForegroundColor Yellow
            Write-Host ''
            return
        }
    }

    Write-Host ''
    $success = $true
    foreach ($target in $targets) {
        Write-Step "Uninstalling $($target.Kind) installation"
        switch ($target.Kind) {
            'Scoop'  { if (-not (Uninstall-CloudflaredScoop -Target $target -DryRun:$DryRun)) { $success = $false } }
            'Manual' { if (-not (Uninstall-CloudflaredManual -Target $target -DryRun:$DryRun)) { $success = $false } }
            default  { Write-Warn "Unknown install kind '$($target.Kind)'; skipped." }
        }
    }

    # Credentials are removed by default so nothing authorized is left behind; -KeepCredentials
    # opts out for people who reinstall right away.
    if (Test-Path -LiteralPath $script:CredDir) {
        if ($removeCredentials) {
            Write-Step "Removing credentials: $($script:CredDir)"
            if ($DryRun) {
                Write-Info "(dry run) would delete $($script:CredDir)"
            } else {
                try {
                    Remove-Item -LiteralPath $script:CredDir -Recurse -Force
                    Write-Ok 'Deleted credential folder'
                } catch {
                    Write-Warn "Could not delete $($script:CredDir): $($_.Exception.Message)"
                    $success = $false
                }
            }
        } else {
            Write-Host ''
            Write-Info "Kept authorization files in $($script:CredDir) (-KeepCredentials)."
        }
    }

    # Verify the result instead of assuming it.
    Write-Host ''
    Write-Host ' Result:' -ForegroundColor White
    foreach ($target in $targets) {
        if ($DryRun) {
            Write-Info "[dry run] would be gone: $($target.Dir)"
        } elseif (Test-Path -LiteralPath $target.Dir) {
            Write-Warn "Still present: $($target.Dir)"
            $success = $false
        } else {
            Write-Ok "Removed: $($target.Dir)"
        }
    }

    $stillOnPath = Get-CloudflaredOnPath
    if ($stillOnPath) {
        Write-Warn "cloudflared still resolves to $stillOnPath"
        Write-Info 'That is often a stale session or a different install listed above; open a new terminal to confirm.'
    } elseif (-not $DryRun) {
        Write-Ok "cloudflared is no longer on PATH in this session"
    }

    $noticePaths = @($notices | ForEach-Object { $_.Path })
    $remaining = Get-CloudflaredCandidatePath | Where-Object {
        (Test-Path -LiteralPath $_) -and ($noticePaths -notcontains $_)
    }
    if ($remaining) {
        Write-Host ''
        Write-Warn 'These cloudflared files are still on disk:'
        foreach ($path in $remaining) { Write-Host "        $path" -ForegroundColor Gray }
    }

    Write-Host ''
    if ($DryRun) {
        Write-Host ' Dry run complete. Nothing was changed.' -ForegroundColor Yellow
    } elseif ($success) {
        Write-Host ' Uninstall complete. No admin rights were used.' -ForegroundColor Green
        if ((Test-Path -LiteralPath $script:CredDir) -and $KeepCredentials) {
            Write-Info "Credentials kept: $($script:CredDir)"
        } elseif (-not (Test-Path -LiteralPath $script:CredDir) -and -not $DryRun -and $removeCredentials) {
            Write-Info 'Credential folder removed as well.'
        }
    } else {
        Write-Host ' Uninstall finished with warnings; see the messages above.' -ForegroundColor Yellow
    }
    Write-Host ''
}


function Invoke-UninstallSshdHost {
    param(
        [switch]$Force,
        [switch]$DryRun,
        [switch]$KeepAuthorizedKeys
    )

    Test-SshdUninstallPrereq

    Write-Host ''
    Write-Host ' user-mode SSH host removal (no admin required)' -ForegroundColor White
    Write-Host ' -----------------------------------------------' -ForegroundColor DarkGray
    if ($DryRun) { Write-Host ' Dry run: nothing will be changed.' -ForegroundColor Yellow }

    $hasInstall = Test-Path -LiteralPath $script:SshHostDir
    $hasConfig = Test-Path -LiteralPath $script:SshConfigDir
    $processes = Get-SshdHostProcess

    if (-not $hasInstall -and -not $hasConfig -and $processes.Count -eq 0) {
        Write-Host ''
        Write-Ok 'No user-mode SSH host from Test-SshdHost.ps1 was found. Nothing to do.'
        Write-Host ''
        return
    }

    if ($hasInstall) { Write-Info "Daemon copy : $script:SshHostDir" }
    if ($hasConfig) { Write-Info "Config/keys : $script:SshConfigDir" }
    if ($processes.Count -gt 0) {
        $pids = ($processes | ForEach-Object { $_.Id }) -join ', '
        Write-Warn "sshd is running (PID: $pids)."
    }

    # Keys this host authorized: the generated client key and any -AddAuthorizedKey entries
    # recorded next to the config.
    # Read the ports before anything is deleted, so the summary can still report them.
    $ports = Get-ListenerPort -ConfigPath (Join-Path $script:SshConfigDir 'sshd_config')

    $generatedKeys = @()
    $clientPub = Join-Path $script:SshConfigDir 'client\id_ed25519.pub'
    if (Test-Path -LiteralPath $clientPub) {
        $generatedKeys += (Get-Content -LiteralPath $clientPub -Raw).Trim()
    }
    $recordFile = Join-Path $script:SshConfigDir 'authorized-keys.txt'
    if (Test-Path -LiteralPath $recordFile) {
        $generatedKeys += @(Get-Content -LiteralPath $recordFile | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | ForEach-Object { $_.Trim() })
    }

    if (-not $DryRun -and -not $Force) {
        if (-not (Test-CanPrompt)) {
            Write-Warn 'No interactive console is available, so nothing was changed. Re-run with -Force to remove it unattended.'
            Write-Host ''
            return
        }
        $answer = Read-Host 'Remove the user-mode SSH host now? [y/N]'
        if ($answer -notmatch '^(y|yes)$') {
            Write-Host ''
            Write-Host ' Cancelled. Nothing was changed.' -ForegroundColor Yellow
            Write-Host ''
            return
        }
    }

    Write-Host ''
    $success = $true

    if ($processes.Count -gt 0) {
        foreach ($process in $processes) {
            if ($DryRun) {
                Write-Step "Would stop sshd PID $($process.Id)"
                continue
            }
            try {
                Stop-Process -Id $process.Id -Force -ErrorAction Stop
                Write-Ok "Stopped sshd PID $($process.Id)"
            } catch {
                Write-Warn "Could not stop PID $($process.Id): $($_.Exception.Message)"
                $success = $false
            }
        }
    }

    if (-not $KeepAuthorizedKeys) {
        $keyFile = Join-Path $env:USERPROFILE '.ssh\authorized_keys'
        if (-not (Revoke-AuthorizedKeyLine -KeyFile $keyFile -KeysToRemove $generatedKeys -DryRun:$DryRun)) {
            $success = $false
        }
    } else {
        Write-Info 'Authorized keys kept (-KeepAuthorizedKeys).'
    }

    foreach ($dir in @($script:SshConfigDir, $script:SshHostDir)) {
        if (-not (Test-Path -LiteralPath $dir)) { continue }
        if ($DryRun) {
            Write-Step "Would delete: $dir"
            continue
        }
        Write-Step "Deleting: $dir"
        try {
            Remove-Item -LiteralPath $dir -Recurse -Force
            Write-Ok "Deleted $dir"
        } catch {
            Write-Warn "Could not delete ${dir}: $($_.Exception.Message)"
            $success = $false
        }
    }

    Write-Host ''
    if ($DryRun) {
        Write-Host ' Dry run complete. Nothing was changed.' -ForegroundColor Yellow
    } elseif ($success) {
        Write-Host ' Removal complete. No admin rights were used.' -ForegroundColor Green
        if ($ports.Count -gt 0) { Write-Info "Port(s) previously used: $($ports -join ', ')" }
    } else {
        Write-Host ' Removal finished with warnings; see the messages above.' -ForegroundColor Yellow
    }
    Write-Host ''
}


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
function Get-PlayitInstallDir {
    if (-not [string]::IsNullOrWhiteSpace($script:PlayitDir)) { return $script:PlayitDir }
    if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) { return $null }
    return (Join-Path $env:LOCALAPPDATA 'playit')
}

function Invoke-UninstallPlayit {
    param([switch]$DryRun)

    $dir = Get-PlayitInstallDir
    if ([string]::IsNullOrWhiteSpace($dir) -or -not (Test-Path -LiteralPath $dir)) {
        Write-Ok "No playit agent folder found at $dir"
        return
    }

    Write-Info "playit folder: $dir"
    $procs = @(Get-Process -Name 'playit' -ErrorAction SilentlyContinue)
    foreach ($proc in $procs) {
        if ($DryRun) {
            Write-Step "Would stop playit PID $($proc.Id)"
            continue
        }
        Write-Step "Stopping playit PID $($proc.Id)"
        try {
            Stop-Process -Id $proc.Id -Force -ErrorAction Stop
            Write-Ok "Stopped playit PID $($proc.Id)"
        } catch {
            Write-Warn "Could not stop playit PID $($proc.Id): $($_.Exception.Message)"
        }
    }

    if ($DryRun) {
        Write-Step "Would delete: $dir"
        return
    }

    Write-Step "Deleting: $dir"
    try {
        Remove-Item -LiteralPath $dir -Recurse -Force
        Write-Ok "Deleted $dir"
    } catch {
        Write-Warn "Could not delete ${dir}: $($_.Exception.Message)"
    }
}

function Test-RemovalPrereq {
    $isWindowsHost = $true
    if ($null -ne $IsWindows) { $isWindowsHost = [bool]$IsWindows }
    if (-not $isWindowsHost) { throw 'This script targets Windows.' }
    if ([string]::IsNullOrWhiteSpace($env:USERPROFILE)) { throw 'USERPROFILE is not set.' }
    if ([string]::IsNullOrWhiteSpace($script:SshHostDir)) {
        if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
            throw 'LOCALAPPDATA is not set, so the SSH host folder cannot be resolved.'
        }
        $script:SshHostDir = Join-Path $env:LOCALAPPDATA 'openssh-host'
    }
    if ([string]::IsNullOrWhiteSpace($script:SshConfigDir)) {
        $script:SshConfigDir = Join-Path $env:USERPROFILE '.ssh-host'
    }
}

function Invoke-Main {
    param(
        [switch]$Cloudflared,
        [switch]$Sshd,
        [switch]$Force,
        [switch]$DryRun,
        [switch]$KeepCredentials,
        [switch]$KeepAuthorizedKeys,
        [switch]$Playit
    )

    Test-RemovalPrereq

    # Without an explicit choice, remove whichever parts are actually present.
    $wantCloudflared = [bool]$Cloudflared
    $wantSshd = [bool]$Sshd
    $wantPlayit = [bool]$Playit
    if (-not $wantCloudflared -and -not $wantSshd -and -not $wantPlayit) {
        $wantCloudflared = $true
        $wantSshd = $true
        $wantPlayit = $true
    }

    Write-Host ''
    Write-Host ' no-admin tools removal (cloudflared / SSH host)' -ForegroundColor White
    Write-Host ' -----------------------------------------------' -ForegroundColor DarkGray
    if ($DryRun) { Write-Host ' Dry run: nothing will be changed.' -ForegroundColor Yellow }

    if ($wantCloudflared) {
        Write-Host ''
        Write-Host '=== cloudflared ===' -ForegroundColor White
        Invoke-UninstallCloudflared -Force:$Force -DryRun:$DryRun -KeepCredentials:$KeepCredentials
    }
    if ($wantSshd) {
        Write-Host ''
        Write-Host '=== SSH host ===' -ForegroundColor White
        Invoke-UninstallSshdHost -Force:$Force -DryRun:$DryRun -KeepAuthorizedKeys:$KeepAuthorizedKeys
    }
    if ($wantPlayit) {
        Write-Host ''
        Write-Host '=== playit.gg agent ===' -ForegroundColor White
        Invoke-UninstallPlayit -DryRun:$DryRun
    }

    Write-Host ''
    if ($DryRun) {
        Write-Host ' Dry run complete. Nothing was changed.' -ForegroundColor Yellow
    } else {
        Write-Host ' Removal run finished. No admin rights were used.' -ForegroundColor Green
    }
    Write-Host ''
}

try {
    Invoke-Main -Cloudflared:$Cloudflared -Sshd:$Sshd -Playit:$Playit -Force:$Force -DryRun:$DryRun `
        -KeepCredentials:$KeepCredentials -KeepAuthorizedKeys:$KeepAuthorizedKeys
} catch {
    Write-Host ''
    Write-Host "[error] $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
