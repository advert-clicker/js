<#
.SYNOPSIS
    Sets up remote SSH access to this computer, with no administrator rights. One command, no
    options: just run .\Install-Tools.ps1

.DESCRIPTION
    Runs the sibling scripts in this folder, in order:

        Install-Sshd.ps1          installs the user-mode sshd, authorizes the keys listed in
                                  trusted-keys.txt, and starts it
        Start-PlayitSsh.ps1       installs the portable playit.gg agent and starts it hidden, so
                                  the SSH host is reachable from the internet, and prints the
                                  exact ssh command for the tunnel

    Everything runs under your own account: no services, no elevation. The two settings that can
    change over time - the SSH port and your playit tunnel address - are at the top of the script;
    edit them there if they ever change.

.NOTES
    If script execution is refused, allow it once for your own account (no admin):
        Get-ChildItem -Path .\*.ps1 | Unblock-File
        Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
#>

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

# ---- settings (edit these if your SSH port or playit tunnel ever changes) ----
$SshdPort     = 2222
$PlayitTunnel = 'hussein-unbutton.tun.ply.gg:58741'

function Write-Step {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Write-Ok {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "[ ok ] $Message" -ForegroundColor Green
}

function Write-Warn {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "[warn] $Message" -ForegroundColor Yellow
}

function Write-Info {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "     $Message" -ForegroundColor Gray
}

function Get-ToolScriptPath {
    # The sibling scripts live next to this one; fail with a clear message if one is missing.
    param([Parameter(Mandatory)][string]$Name)

    $root = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
    $path = Join-Path $root $Name
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "$Name was not found next to this script (looked in $root)."
    }
    return $path
}

function Invoke-ToolScript {
    # Runs one of the sibling scripts with named parameters and reports the result.
    #
    # Parameters MUST be passed as a hashtable of name -> value and splatted as "@Params".
    # Splatting a flat array like @('-Port', '2222') does not work: PowerShell treats those as
    # positional arguments, so the string '-Port' is bound to -Port and the conversion fails
    # with "Cannot convert value "-Port" to type "System.Int32"".
    param(
        [Parameter(Mandatory)][string]$Name,
        [hashtable]$Parameters = @{}
    )

    $path = Get-ToolScriptPath -Name $Name

    $argumentList = New-Object System.Collections.Generic.List[string]
    foreach ($key in $Parameters.Keys) {
        $value = $Parameters[$key]
        if ($value -is [System.Management.Automation.SwitchParameter] -or $value -is [bool]) {
            if ($value) { $argumentList.Add("-$key") }
            continue
        }
        if ($null -eq $value -or ([string]$value).Length -eq 0) { continue }
        $argumentList.Add("-$key")
        $argumentList.Add(([string]$value))
    }

    Write-Step "Running $Name $($argumentList -join ' ')"

    # Prefer the same PowerShell host that is running this script: it is guaranteed to exist and
    # behaves identically for the child. -ExecutionPolicy is a Windows-only switch, so it is only
    # added when the host actually supports it.
    $hostExe = (Get-Process -Id $PID).Path
    if ([string]::IsNullOrWhiteSpace($hostExe) -or -not (Test-Path -LiteralPath $hostExe -PathType Leaf)) {
        $hostExe = 'powershell.exe'
        if ($null -eq (Get-Command -Name 'powershell.exe' -ErrorAction SilentlyContinue)) { $hostExe = 'pwsh' }
    }

    $childArgs = @('-NoProfile')
    if ($IsWindows -or ($null -eq $IsWindows)) { $childArgs += @('-ExecutionPolicy', 'RemoteSigned') }
    $childArgs += @('-File', $path)
    $childArgs += $argumentList.ToArray()

    # How the child is launched matters more than it looks.
    #
    # The child starts sshd / starts the playit agent, each of which leaves a long-lived
    # background process behind. Those processes inherit the child's stdout. If this script
    # captures the child's output ("& $hostExe ... 2>&1" or -RedirectStandardOutput), the pipe
    # stays open for as long as the daemon lives, the read never reaches EOF, and the run
    # appears frozen on "Running Start-PlayitSsh.ps1 ...".
    #
    # Start-Process -NoNewWindow -PassThru gives the child the console directly and lets us wait
    # on the process object instead of on a stream, so this returns as soon as the child exits
    # while its daemons keep running.
    $global:LASTEXITCODE = 0
    $child = Start-Process -FilePath $hostExe -ArgumentList $childArgs -NoNewWindow -PassThru

    # Cache the process handle the instant it starts. Without this, .NET releases the handle once
    # the process exits and .ExitCode then reads back as $null, which showed up as
    # "exited, but its exit code could not be read" even on a clean (exit 0) run.
    try { $null = $child.Handle } catch { $null = $_ }

    $child.WaitForExit()

    $code = $null
    try { $code = $child.ExitCode } catch { $code = $null }

    if ($null -ne $code -and $code -ne 0) {
        Write-Warn "$Name exited with code $code."
        return $false
    }
    if ($null -eq $code) {
        # With the handle cached this is rare. The child prints its own errors to the console, so
        # treat an unreadable code as success rather than inventing a failure.
        Write-Info "$Name finished (exit code was not reported)."
        return $true
    }
    Write-Ok "$Name finished"
    return $true
}

try {
    Write-Host ''
    Write-Host ' remote SSH access setup (no admin)' -ForegroundColor White
    Write-Host ' ----------------------------------' -ForegroundColor DarkGray
    Write-Info "SSH host     : port $SshdPort"
    Write-Info "playit tunnel: $PlayitTunnel"

    $failed = @()

    if (-not (Invoke-ToolScript -Name 'Install-Sshd.ps1' -Parameters @{ Port = $SshdPort; Start = $true })) {
        $failed += 'sshd'
    }

    if (-not (Invoke-ToolScript -Name 'Start-PlayitSsh.ps1' -Parameters @{ SshPort = $SshdPort; StartAgent = $true; TunnelAddress = $PlayitTunnel })) {
        $failed += 'playit'
    }

    Write-Host ''
    if ($failed.Count -gt 0) {
        Write-Warn "These parts did not finish cleanly: $($failed -join ', ')"
        Write-Info 'Each part is its own script, so you can rerun just that one to see the full error.'
        exit 1
    }

    Write-Host ' All set. No admin rights were used.' -ForegroundColor Green
    Write-Info 'The playit step above printed the exact ssh command to connect from another machine.'
    Write-Host ''
} catch {
    Write-Host ''
    Write-Host "[error] $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
